import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const CalculatorApp = () => {
  const [input, setInput] = useState('');
  const [result, setResult] = useState('');

  const handleButtonPress = (value) => {
    if (value === '=') {
      setResult(eval(input).toString());
    } else if (value === 'C') {
      setInput('');
      setResult('');
    } else {
      setInput(input + value);
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        value={input}
        editable={false}
      />
      <Text style={styles.result}>{result}</Text>
      <View style={styles.buttonsContainer}>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('7')}><Text style={styles.buttonText}>7</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('8')}><Text style={styles.buttonText}>8</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('9')}><Text style={styles.buttonText}>9</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('/')}><Text style={styles.buttonText}>÷</Text></TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('4')}><Text style={styles.buttonText}>4</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('5')}><Text style={styles.buttonText}>5</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('6')}><Text style={styles.buttonText}>6</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('*')}><Text style={styles.buttonText}>×</Text></TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('1')}><Text style={styles.buttonText}>1</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('2')}><Text style={styles.buttonText}>2</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('3')}><Text style={styles.buttonText}>3</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('-')}><Text style={styles.buttonText}>−</Text></TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('0')}><Text style={styles.buttonText}>0</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('.')}><Text style={styles.buttonText}>.</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('=')}><Text style={styles.buttonText}>=</Text></TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('+')}><Text style={styles.buttonText}>+</Text></TouchableOpacity>

        <TouchableOpacity style={styles.button} onPress={() => handleButtonPress('C')}><Text style={[styles.buttonText, { color: 'red' }]}>C</Text></TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  input: {
    height: 40,
    width: '80%',
    borderColor: '#dcdcdc',
    borderWidth: 1,
    marginBottom: 10,
    textAlign: 'right',
    paddingHorizontal: 10,
    backgroundColor: '#fff',
    fontSize: 28,
    fontWeight: 'bold',
  },
  result: {
    fontSize: 40,
    marginBottom: 10,
  },
  buttonsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
  },
  button: {
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#e0e0e0',
    minWidth: '25%',
    height: 80,
    marginVertical: 5,
    borderRadius: 40,
  },
  buttonText: {
    fontSize: 36,
    color: '#333',
    fontWeight: 'bold',
  },
});

export default CalculatorApp;
